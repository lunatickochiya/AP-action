### 支持版本

OpenWrt 21 及以上
### 使用gettext命令提取js文件文本信息
