#ifndef __AF_CLIENT_FS_H__
#define __AF_CLIENT_FS_H__

int init_af_client_procfs(void);
void finit_af_client_procfs(void);

#endif
