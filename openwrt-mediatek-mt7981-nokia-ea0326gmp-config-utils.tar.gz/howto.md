** Note **
The binaries are dynamically linked with aarch64 musl 1.1.24. To use
them, you must put them into the same runtime environment, otherwise
the binaries will not work properly.

** Prepare **
mv mkconfig seama /bin
chmod +x /bin/mkconfig
chmod +x /bin/seama

** Decrypt the configuration **
mkconfig -a de-enca -m EA0326GMP_3FE79221BAAA -i EA0326GMP_3FE79221BAAA-xxxxxxxx-backup.tar.gz -o backup.tar.gz

** Encrypt the configuration **
mkconfig -a enca -m EA0326GMP_3FE79221BAAA -i backup.tar.gz -o EA0326GMP_3FE79221BAAA-xxxxxxxx-backup.tar.gz
